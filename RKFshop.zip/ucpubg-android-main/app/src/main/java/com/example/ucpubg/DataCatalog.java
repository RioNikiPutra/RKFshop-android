package com.example.ucpubg;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.ByteArrayOutputStream;
import java.util.Random;

public class DataCatalog extends AppCompatActivity {

    TextView nametext,hargatext,stoktext,kodetext,totaltext,emailtext;
    String nama,stok,totalbayar,kodebayar,emailuser;
    Integer harga,abcd,total;
    ImageView myavatar;
    Button but1;
    AlertDialog dialog;
    Drawable drawable;
    public static final int MY_PERMISSIONS_REQUEST_CAMERA = 100;
    public static final String ALLOW_KEY = "ALLOWED";
    public static final String CAMERA_PREF = "camera_pref";
    Bitmap thumbnail;
    Transaksi transaksi;
    Database databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_catalog);
        System.out.println(Preferences.getLoggedInUser(getBaseContext())+"asasda sad ads ag");
        Bundle bundle = getIntent().getExtras();
         nama = bundle.getString("produk");
         harga = bundle.getInt("harga",0);
         stok = bundle.getString("stok");
         stok = bundle.getString("stok");
//         emailuser = bundle.getString("email");

        Resources res = getResources();;
        drawable = res.getDrawable(R.drawable.uc_image);

        initView();
        initObjects();
        emailtext = findViewById(R.id.textView2);
        emailuser=Preferences.getLoggedInUser(getBaseContext());

        Log.d("cek email disiinii",emailuser);
        emailtext.setText(emailuser);

        but1=findViewById(R.id.button2);
        but1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAlertDialog();
            }
        });

    }
    private void initObjects() {
//        inputValidation = new InputValidation(activity);
        databaseHelper = new Database(this);
        transaksi = new Transaksi();

    }
    void permissionCamera(){
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            if (getFromPref(this, ALLOW_KEY)) {
                showSettingsAlert();
            } else if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.CAMERA)

                    != PackageManager.PERMISSION_GRANTED) {

                // Should we show an explanation?
                if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                        Manifest.permission.CAMERA)) {
                    showAlert();
                } else {
                    // No explanation needed, we can request the permission.
                    ActivityCompat.requestPermissions(this,
                            new String[]{Manifest.permission.CAMERA},
                            MY_PERMISSIONS_REQUEST_CAMERA);
                }
            }
        } else {
            openCamera();
        }
    }
    void initView(){
        nametext = findViewById(R.id.produkText);
        hargatext = findViewById(R.id.hargaText);
        stoktext = findViewById(R.id.stokText);
        myavatar = findViewById(R.id.avatar);
        kodetext = findViewById(R.id.kodeText);
        totaltext = findViewById(R.id.totalText);

        Random rand = new Random();
        abcd = rand.nextInt(999);
        total = abcd+harga;

        kodebayar = "Kode Bayar : "+abcd.toString();
        totalbayar = "Total Bayar : "+total.toString();

        nametext.setText(nama);
        hargatext.setText("IDR"+ harga);
        stoktext.setText(stok);
        kodetext.setText(kodebayar);
        totaltext.setText(totalbayar);
        myavatar.setImageDrawable(drawable);
    }
    void showAlertDialog(){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setMessage("Buy and Upload Bukti using Camera?")
                .setCancelable(false)
                .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Log.d("save","simpann dongsss "+nama+totalbayar);
                        permissionCamera();
                    }
                })
                .setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialog.cancel();
                    }
                });
        dialog= builder.create();
        dialog.show();
    }
    void saveTransaction(){
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] img = baos.toByteArray();
//        Preferences.getLoggedInUser(getBaseContext());
        Log.d("emailnya",emailtext.getText().toString());
        Log.d("produk",nama);
        Log.d("total",total.toString());
//        Log.d("blob",img.length);
        transaksi.setEmailuser(emailtext.getText().toString());
        transaksi.setProdukname(nama);
        transaksi.setJumlah(1);
        transaksi.setTotal(total);
        transaksi.setBukti(img);

        databaseHelper.addTransaction(transaksi);
        Intent intent=new Intent(this, HistoryActivity.class);
        startActivity(intent);
    }
    public static void saveToPreferences(Context context, String key, Boolean allowed) {
        SharedPreferences myPrefs = context.getSharedPreferences(CAMERA_PREF,
                Context.MODE_PRIVATE);
        SharedPreferences.Editor prefsEditor = myPrefs.edit();
        prefsEditor.putBoolean(key, allowed);
        prefsEditor.commit();
    }

    public static Boolean getFromPref(Context context, String key) {
        SharedPreferences myPrefs = context.getSharedPreferences(CAMERA_PREF,
                Context.MODE_PRIVATE);
        return (myPrefs.getBoolean(key, false));
    }

    private void showAlert() {
        AlertDialog alertDialog = new AlertDialog.Builder(DataCatalog.this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage("App needs to access the Camera.");

        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "DONT ALLOW",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        finish();
                    }
                });

        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "ALLOW",
                new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        ActivityCompat.requestPermissions(DataCatalog.this,
                                new String[]{Manifest.permission.CAMERA},
                                MY_PERMISSIONS_REQUEST_CAMERA);
                    }
                });
        alertDialog.show();
    }

    private void showSettingsAlert() {
        AlertDialog alertDialog = new AlertDialog.Builder(DataCatalog.this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage("App needs to access the Camera.");

        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "DONT ALLOW",
                new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        //finish();
                    }
                });

        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "SETTINGS",
                new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        startInstalledAppDetailsActivity(DataCatalog.this);
                    }
                });

        alertDialog.show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_CAMERA: {
                for (int i = 0, len = permissions.length; i < len; i++) {
                    String permission = permissions[i];

                    if (grantResults[i] == PackageManager.PERMISSION_DENIED) {
                        boolean
                                showRationale =
                                ActivityCompat.shouldShowRequestPermissionRationale(
                                        this, permission);

                        if (showRationale) {
                            showAlert();
                        } else if (!showRationale) {
                            saveToPreferences(DataCatalog.this, ALLOW_KEY, true);
                        }
                    }
                }
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    public static void startInstalledAppDetailsActivity(final Activity context) {
        if (context == null) {
            return;
        }

        final Intent i = new Intent();
        i.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        i.addCategory(Intent.CATEGORY_DEFAULT);
        i.setData(Uri.parse("package:" + context.getPackageName()));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        context.startActivity(i);
    }

    private void openCamera() {
        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        startActivityForResult(intent,MY_PERMISSIONS_REQUEST_CAMERA);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        System.out.println("requescode : "+requestCode);
        if(requestCode == MY_PERMISSIONS_REQUEST_CAMERA){
            if(resultCode == RESULT_OK) {
                Log.d("emailnya",emailtext.getText().toString());
                System.out.println("sampe sini boy");
                onCaptureImageResult(data);
                saveTransaction();
            }
        }
    }
    private void onCaptureImageResult(Intent data) {
        thumbnail = (Bitmap) data.getExtras().get("data");

        //set Progress Bar
//        setProgressBar();
//        //set profile picture form camera
//        profileImageView.setMaxWidth(200);
//        profileImageView.setImageBitmap(thumbnail);
    }
}
