package com.example.ucpubg;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;

public class AccountActivity extends AppCompatActivity {
    BottomNavigationView navigation;
    private List<User> users = new ArrayList<User>();
    private Database databaseHelper;
    TextView nama,email,logout;
    AlertDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        navigation = findViewById(R.id.navigation);
        navigation.setSelectedItemId(R.id.accountMenu);
        navigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.homeMenu:
                        Intent a = new Intent(AccountActivity.this, CatalogActivity.class);
                        startActivity(a);

                        break;
                    case R.id.historyMenu:
                        Intent b = new Intent(AccountActivity.this, HistoryActivity.class);
                        startActivity(b);

                        break;
                    case R.id.accountMenu:
//                        Intent c = new Intent(AccountActivity.this, AccountActivity.class);
//                        startActivity(c);
                        break;
                }
                return false;
            }
        });
        initObjects();
        initView();
    }
    void initView(){
        nama=findViewById(R.id.textView6);
        email=findViewById(R.id.textView7);
        logout=findViewById(R.id.textView4);

        nama.setText("Your Name : "+users.get(0).getName());
        email.setText("Your Email : "+users.get(0).getEmail());

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAlertDialog();
            }
        });
    }
    private void initObjects() {
        databaseHelper = new Database(this);
        users.clear();
        users.addAll(databaseHelper.getAllUser(Preferences.getLoggedInUser(getBaseContext())));
    }
    void showAlertDialog(){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setMessage("Are you sure to Sign Out?")
                .setCancelable(false)
                .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Log.d("sign out","Keluarrr");
//                        permissionCamera();
                        Preferences.clearLoggedInUser(getBaseContext());
                        Intent iLogout = new Intent(getApplicationContext(),LoginActivity.class);
                        startActivity(iLogout);
                    }
                })
                .setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialog.cancel();
                    }
                });
        dialog= builder.create();
        dialog.show();
    }
}