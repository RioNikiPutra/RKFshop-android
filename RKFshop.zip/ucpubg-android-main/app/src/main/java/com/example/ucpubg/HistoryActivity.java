package com.example.ucpubg;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {

//    private RecyclerView recyclerViewUsers;
    private ListView listView;
    private List<Transaksi> transaksis = new ArrayList<Transaksi>();
    private Database databaseHelper;
    private HistoryAdapter listAdapter;
    BottomNavigationView navigation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        navigation = findViewById(R.id.navigation);
        navigation.setSelectedItemId(R.id.historyMenu);
        navigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.homeMenu:
                        Intent a = new Intent(HistoryActivity.this, CatalogActivity.class);
                        startActivity(a);

                        break;
                    case R.id.historyMenu:
//                        Intent b = new Intent(HistoryActivity.this, HistoryActivity.class);
//                        startActivity(b);

                        break;
                    case R.id.accountMenu:
                        Intent c = new Intent(HistoryActivity.this, AccountActivity.class);
                        startActivity(c);
                        break;
                }
                return false;
            }
        });
        listView = findViewById(R.id.listHistory);
        initObjects();
        listView.setAdapter(listAdapter);
    }
    void botNav(){

    }
    private void initObjects() {
//        transaksis = new ArrayList<>();
        databaseHelper = new Database(this);
        getDataFromSQLite();
        listAdapter = new HistoryAdapter(transaksis, this);
    }
    @SuppressLint("StaticFieldLeak")
    private void getDataFromSQLite() {
        // AsyncTask is used that SQLite operation not blocks the UI Thread.
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... params) {
                transaksis.clear();
                transaksis.addAll(databaseHelper.getAllTransaction(Preferences.getLoggedInUser(getBaseContext())));

                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                listAdapter.notifyDataSetChanged();
            }
        }.execute();
    }
}