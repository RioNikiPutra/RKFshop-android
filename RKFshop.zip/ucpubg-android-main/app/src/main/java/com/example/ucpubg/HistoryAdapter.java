package com.example.ucpubg;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class HistoryAdapter extends BaseAdapter {
    private List<Transaksi> transaksis;
    Context context;
    LayoutInflater inflater;
    Database database;

    public HistoryAdapter(List<Transaksi> transaksis, Context context) {
        this.transaksis = transaksis;
        this.context = context;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return transaksis.size();
    }

    @Override
    public Object getItem(int i) {
        return transaksis.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        // Isi convertView
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_history, null);
            holder = new ViewHolder();
            holder.avatarHistory = convertView.findViewById(R.id.avatarHistory);
            holder.nameHistory = convertView.findViewById(R.id.nameTextHistory);
            holder.hargaHistory = convertView.findViewById(R.id.hargaTextHistory);
            holder.stokHistory = convertView.findViewById(R.id.textView3);
            holder.emailHistory = convertView.findViewById(R.id.stokTextHistory);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        // Ngisi data
        holder.nameHistory.setText(transaksis.get(position).getProdukname());
        holder.hargaHistory.setText("IDR "+ transaksis.get(position).getTotal().toString());
        holder.stokHistory.setText(transaksis.get(position).getJumlah().toString()+"x");
        holder.emailHistory.setText(transaksis.get(position).getEmailuser());
        byte[] buktiImage = transaksis.get(position).getBukti();
        Bitmap bitmap = BitmapFactory.decodeByteArray(buktiImage, 0, buktiImage.length);
        holder.avatarHistory.setImageBitmap(bitmap);

//        holder.avatarView.setImageDrawable(context.getResources().getDrawable(R.drawable.uc_image));

        // Kembalikan view yg sudah diisi
        return convertView;
    }

    static class ViewHolder {
        ImageView avatarHistory;
        TextView nameHistory;
        TextView hargaHistory;
        TextView stokHistory;
        TextView emailHistory;
    }
}
