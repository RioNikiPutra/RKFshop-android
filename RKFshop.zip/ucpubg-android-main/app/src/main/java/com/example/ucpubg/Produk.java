package com.example.ucpubg;


public class Produk {
    private String produk;
    private Integer harga;
    private String stok;

    public Produk(String produk, Integer harga, String stok) {
        this.produk = produk;
        this.harga = harga;
        this.stok = stok;
    }

    public String getProduk() {
        return produk;
    }

    public void setProduk(String produk) {
        this.produk = produk;
    }

    public Integer getHarga() {
        return harga;
    }

    public void setHarga(int harga) {
        this.harga = harga;
    }

    public String getStok() {
        return stok;
    }

    public void setStok(String stok) {
        this.stok = stok;
    }
}
