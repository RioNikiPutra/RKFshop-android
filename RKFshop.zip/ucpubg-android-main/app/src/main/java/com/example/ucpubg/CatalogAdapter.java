package com.example.ucpubg;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class CatalogAdapter extends BaseAdapter {
    private List<Produk> produks;
    Context context;
    LayoutInflater inflater;

    public CatalogAdapter(List<Produk> produks, Context context) {
        this.produks = produks;
        this.context = context;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return produks.size();
    }

    @Override
    public Object getItem(int i) {
        return produks.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        // Isi convertView
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_artist, null);
            holder = new ViewHolder();
            holder.avatarView = convertView.findViewById(R.id.avatar);
            holder.nameView = convertView.findViewById(R.id.nameText);
            holder.harga = convertView.findViewById(R.id.harga);
            holder.stok = convertView.findViewById(R.id.stok);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        // Ngisi data
        holder.nameView.setText(produks.get(position).getProduk());
        holder.harga.setText(produks.get(position).getHarga().toString());
        holder.stok.setText(produks.get(position).getStok());

        // Tambahkan bendera
//        int id = context.getResources().getIdentifier(
//                "bbr_" + produks.get(position).getCountryCode(),
//                "drawable", context.getPackageName());
        holder.avatarView.setImageDrawable(context.getResources().getDrawable(R.drawable.uc_image));

        // Kembalikan view yg sudah diisi
        return convertView;
    }

    static class ViewHolder {
        ImageView avatarView;
        TextView nameView;
        TextView harga;
        TextView stok;
    }
}
